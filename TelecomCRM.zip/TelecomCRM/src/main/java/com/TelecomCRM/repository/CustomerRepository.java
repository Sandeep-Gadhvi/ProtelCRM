package com.TelecomCRM.repository;

import com.TelecomCRM.model.Customer;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Long> {


    // Custom query method to find customers by last name
    List<Customer> findByLastName(String lastName);

    // Custom query method to find customers by first name and last name
    List<Customer> findByFirstNameAndLastName(String firstName, String lastName);

    // Custom query method to find customers by email
    Customer findByEmail(String email);

    boolean existsByEmail(String email);
}
