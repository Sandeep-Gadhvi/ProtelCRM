package com.TelecomCRM.controller;
import com.TelecomCRM.model.MyService;
import com.TelecomCRM.services.MyServiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/services")
public class MyServiceController {

    @Autowired
    private MyServiceService serviceService;

    @GetMapping
    public List<MyService> getAllServices() {
        return serviceService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<MyService> getServiceById(@PathVariable Long id) {
        Optional<MyService> service = serviceService.findById(id);
        return service.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public MyService createService(@RequestBody MyService service) {
        return serviceService.save(service);
    }

    @PutMapping("/{id}")
    public ResponseEntity<MyService> updateService(@PathVariable Long id, @RequestBody MyService serviceDetails) {
        Optional<MyService> service = serviceService.findById(id);
        if (service.isPresent()) {
            MyService updatedService = service.get();
            updatedService.setName(serviceDetails.getName());
            return ResponseEntity.ok(serviceService.save(updatedService));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteService(@PathVariable Long id) {
        serviceService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Find services by name
    @GetMapping("/name/{name}")
    public ResponseEntity<List<MyService>> getServicesByName(@PathVariable String name) {
        List<MyService> services = serviceService.findByName(name);
        return ResponseEntity.ok(services);
    }

    // Find services by type
    @GetMapping("/type/{type}")
    public ResponseEntity<List<MyService>> getServicesByType(@PathVariable String type) {
        List<MyService> services = serviceService.findByType(type);
        return ResponseEntity.ok(services);
    }
}


