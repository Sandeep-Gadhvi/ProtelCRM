package com.TelecomCRM.model;

import java.util.List;

import jakarta.persistence.*;


@Entity
public class Subscription {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String status;

    private String subscriptionType;
    @ManyToOne
    private MyService service;

    @ManyToOne
    @JoinColumn(name = "customer_id")
    private Customer customer;

    @OneToMany(mappedBy = "subscription", cascade = CascadeType.ALL)
    private List<Invoice> invoices;

    public Subscription() {
    }

    public Subscription(Long id, String subscriptionType, Customer customer, List<Invoice> invoices) {
        this.id = id;
        this.subscriptionType = subscriptionType;
        this.customer = customer;
        this.invoices = invoices;
    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getSubscriptionType() { return subscriptionType; }
    public void setSubscriptionType(String subscriptionType) { this.subscriptionType = subscriptionType; }

    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer customer) { this.customer = customer; }

    public List<Invoice> getInvoices() { return invoices; }
    public void setInvoices(List<Invoice> invoices) { this.invoices = invoices; }

    @Override
    public String toString() {
        return "Subscription{" +
                "id=" + id +
                ", subscriptionType='" + subscriptionType + '\'' +
                ", customer=" + customer +
                ", invoices=" + invoices +
                '}';
    }
}