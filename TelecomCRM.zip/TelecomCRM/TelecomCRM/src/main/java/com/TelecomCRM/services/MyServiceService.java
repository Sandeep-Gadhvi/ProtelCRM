package com.TelecomCRM.services;
import com.TelecomCRM.model.MyService;
import com.TelecomCRM.repository.MyServiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class MyServiceService {
    @Autowired
    private MyServiceRepository serviceRepository;

    public List<MyService> findAll() {
        return serviceRepository.findAll();
    }

    public Optional<MyService> findById(Long id) {
        return serviceRepository.findById(id);
    }

    public MyService save(MyService service) {
        return serviceRepository.save(service);
    }

    public void deleteById(Long id) {
        serviceRepository.deleteById(id);
    }

    public List<MyService> findByName(String name) {
        return serviceRepository.findByName(name);
    }

    public List<MyService> findByType(String type) {
        return serviceRepository.findByType(type);
    }

}
