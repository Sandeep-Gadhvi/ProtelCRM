package com.TelecomCRM.controller;

import com.TelecomCRM.model.Customer;
import com.TelecomCRM.model.MyService;
import com.TelecomCRM.model.Subscription;
import com.TelecomCRM.services.SubscriptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/subscriptions")

public class SubscriptionController {
    @Autowired
    private SubscriptionService subscriptionService;

    @GetMapping
    public List<Subscription> getAllSubscriptions() {
        return subscriptionService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Subscription> getSubscriptionById(@PathVariable Long id) {
        Optional<Subscription> subscription = subscriptionService.findById(id);
        return subscription.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping("/subscription")
    public Subscription createSubscription(@RequestBody Subscription subscription) {
        return subscriptionService.save(subscription);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Subscription> updateSubscription(@PathVariable Long id, @RequestBody Subscription subscriptionDetails) {
        Optional<Subscription> subscription = subscriptionService.findById(id);
        if (subscription.isPresent()) {
            Subscription updatedSubscription = subscription.get();
            updatedSubscription.setSubscriptionType(subscriptionDetails.getSubscriptionType());
            updatedSubscription.setCustomer(subscriptionDetails.getCustomer());
            return ResponseEntity.ok(subscriptionService.save(updatedSubscription));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteSubscription(@PathVariable Long id) {
        subscriptionService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Find subscriptions by customer
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Subscription>> getSubscriptionsByCustomer(@PathVariable Long customerId) {
        // Assuming you have a way to get the Customer object, e.g., via a CustomerService or repository
        // For now, using a dummy Customer object
        Customer customer = new Customer();
        customer.setId(customerId);
        List<Subscription> subscriptions = subscriptionService.findByCustomer(customer);
        return ResponseEntity.ok(subscriptions);
    }

    // Find subscriptions by service
    @GetMapping("/service/{serviceId}")
    public ResponseEntity<List<Subscription>> getSubscriptionsByService(@PathVariable Long serviceId) {
        // Assuming you have a way to get the Service object, e.g., via a ServiceService or repository
        // For now, using a dummy Service object
        MyService service = new MyService();
        service.setId(serviceId);
        List<Subscription> subscriptions = subscriptionService.findByService(service);
        return ResponseEntity.ok(subscriptions);
    }

    // Find subscriptions by status
    @GetMapping("/status/{status}")
    public ResponseEntity<List<Subscription>> getSubscriptionsByStatus(@PathVariable String status) {
        List<Subscription> subscriptions = subscriptionService.findByStatus(status);
        return ResponseEntity.ok(subscriptions);
    }
}
