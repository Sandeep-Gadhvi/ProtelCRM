package com.TelecomCRM;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TelecomCrmApplicationTests {

	@Test
	void contextLoads() {
	}

}
