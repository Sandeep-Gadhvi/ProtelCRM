package com.TelecomCRM.services;

import com.TelecomCRM.model.Tickets;
import com.TelecomCRM.repository.TicketRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class TicketService {

    @Autowired
    private TicketRepository ticketRepository;

    public List<Tickets> getAllTickets() {
        return ticketRepository.findAll();
    }

    public Optional<Tickets> getTicketById(Long id) {
        return ticketRepository.findById(id);
    }

    public List<Tickets> getTicketsByStatus(String status) {
        return ticketRepository.findByStatus(status);
    }

    public List<Tickets> getTicketsByCustomerId(Long customerId) {
        return ticketRepository.findByCustomerId(customerId);
    }

    public Tickets createTicket(Tickets ticket) {
        return ticketRepository.save(ticket);
    }

    public void resolveTicket(Long id) {
        Optional<Tickets> ticketOpt = ticketRepository.findById(id);
        if (ticketOpt.isPresent()) {
            Tickets ticket = ticketOpt.get();
            ticket.setStatus("RESOLVED");
            ticket.setResolvedAt(new Date());
            ticketRepository.save(ticket);
        }
    }

    public void deleteTicket(Long id) {
        ticketRepository.deleteById(id);
    }
}
