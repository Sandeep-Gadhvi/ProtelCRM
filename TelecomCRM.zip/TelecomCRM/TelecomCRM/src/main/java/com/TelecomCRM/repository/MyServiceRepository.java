package com.TelecomCRM.repository;
import com.TelecomCRM.model.MyService;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface MyServiceRepository extends JpaRepository<MyService, Long>{
    List<MyService> findByName(String name);
    List<MyService> findByType(String type);

}
