package com.TelecomCRM.controller;
import com.TelecomCRM.model.Invoice;
import com.TelecomCRM.model.Subscription;
import com.TelecomCRM.model.Customer;
import com.TelecomCRM.services.InvoiceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/invoices")
public class InvoiceController {

    @Autowired
    private InvoiceService invoiceService;

    @GetMapping
    public List<Invoice> getAllInvoices() {
        return invoiceService.findAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Invoice> getInvoiceById(@PathVariable Long id) {
        Optional<Invoice> invoice = invoiceService.findById(id);
        return invoice.map(ResponseEntity::ok)
                .orElseGet(() -> ResponseEntity.notFound().build());
    }

    @PostMapping
    public Invoice createInvoice(@RequestBody Invoice invoice) {
        return invoiceService.save(invoice);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Invoice> updateInvoice(@PathVariable Long id, @RequestBody Invoice invoiceDetails) {
        Optional<Invoice> invoice = invoiceService.findById(id);
        if (invoice.isPresent()) {
            Invoice updatedInvoice = invoice.get();
            updatedInvoice.setAmount(invoiceDetails.getAmount());
            updatedInvoice.setInvoiceDate(invoiceDetails.getInvoiceDate());
            updatedInvoice.setSubscription(invoiceDetails.getSubscription());
            return ResponseEntity.ok(invoiceService.save(updatedInvoice));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteInvoice(@PathVariable Long id) {
        invoiceService.deleteById(id);
        return ResponseEntity.noContent().build();
    }

    // Find invoices by customer
    @GetMapping("/customer/{customerId}")
    public ResponseEntity<List<Invoice>> getInvoicesByCustomer(@PathVariable Long customerId) {
        // Replace with actual logic to fetch Customer object
        Customer customer = new Customer();
        customer.setId(customerId);
        List<Invoice> invoices = invoiceService.findByCustomer(customer);
        return ResponseEntity.ok(invoices);
    }

    // Find invoices by subscription
    @GetMapping("/subscription/{subscriptionId}")
    public ResponseEntity<List<Invoice>> getInvoicesBySubscription(@PathVariable Long subscriptionId) {
        // Replace with actual logic to fetch Subscription object
        Subscription subscription = new Subscription();
        subscription.setId(subscriptionId);
        List<Invoice> invoices = invoiceService.findBySubscription(subscription);
        return ResponseEntity.ok(invoices);
    }

}
