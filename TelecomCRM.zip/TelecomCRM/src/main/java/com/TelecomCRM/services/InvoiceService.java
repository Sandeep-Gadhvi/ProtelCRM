package com.TelecomCRM.services;

import com.TelecomCRM.model.Customer;
import com.TelecomCRM.model.Invoice;
import com.TelecomCRM.model.Subscription;
import com.TelecomCRM.repository.InvoiceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class InvoiceService {

    @Autowired
    private InvoiceRepository invoiceRepository;

    public List<Invoice> findAll() {
        return invoiceRepository.findAll();
    }

    public Optional<Invoice> findById(Long id) {
        return invoiceRepository.findById(id);
    }

    public Invoice save(Invoice invoice) {
        return invoiceRepository.save(invoice);
    }

    public void deleteById(Long id) {
        invoiceRepository.deleteById(id);
    }

    public List<Invoice> findByCustomer(Customer customer) {
        return invoiceRepository.findByCustomer(customer);
    }

    public List<Invoice> findBySubscription(Subscription subscription) {
        return invoiceRepository.findBySubscription(subscription);
    }


}
