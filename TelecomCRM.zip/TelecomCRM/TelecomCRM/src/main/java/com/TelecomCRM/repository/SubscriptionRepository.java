package com.TelecomCRM.repository;
import com.TelecomCRM.model.Customer;
import com.TelecomCRM.model.MyService;
import com.TelecomCRM.model.Subscription;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface SubscriptionRepository extends JpaRepository<Subscription, Long> {

    // Find all subscriptions by a specific customer
    List<Subscription> findByCustomer(Customer customer);

    // Find all subscriptions for a specific service
    List<Subscription> findByService(MyService name);

    // Find all subscriptions with a specific status
    List<Subscription> findByStatus(String status);
}

