package com.TelecomCRM.services;
import com.TelecomCRM.model.Customer;
import com.TelecomCRM.model.MyService;
import com.TelecomCRM.model.Subscription;
import com.TelecomCRM.repository.SubscriptionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SubscriptionService {

    @Autowired
    private SubscriptionRepository subscriptionRepository;

    public List<Subscription> findAll() {
        return subscriptionRepository.findAll();
    }

    public Optional<Subscription> findById(Long id) {
        return subscriptionRepository.findById(id);
    }

    public Subscription save(Subscription subscription) {
        return subscriptionRepository.save(subscription);
    }

    public void deleteById(Long id) {
        subscriptionRepository.deleteById(id);
    }
    // Find subscriptions by customer
    public List<Subscription> findByCustomer(Customer customer) {
        return subscriptionRepository.findByCustomer(customer);
    }

    // Find subscriptions by service
    public List<Subscription> findByService(MyService serviceName) {
        return subscriptionRepository.findByService(serviceName);
    }

    // Find subscriptions by status
    public List<Subscription> findByStatus(String status) {
        return subscriptionRepository.findByStatus(status);
    }
}
