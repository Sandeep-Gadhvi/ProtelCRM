package com.TelecomCRM.model;

import jakarta.persistence.*;

import java.time.LocalDate;

@Entity
public class Invoice {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Double amount;
    private LocalDate invoiceDate;

    @ManyToOne
    @JoinColumn
    private Customer customer;

    @ManyToOne
    private Subscription subscription;

    public Invoice(Long id, Double amount, LocalDate invoiceDate, Customer customer, Subscription subscription) {
        this.id = id;
        this.amount = amount;
        this.invoiceDate = invoiceDate;
        this.customer = customer;
        this.subscription = subscription;
    }

    public Invoice() {

    }

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Double getAmount() { return amount; }
    public void setAmount(Double amount) { this.amount = amount; }

    public Customer getCustomer() { return customer; }
    public void setCustomer(Customer customer) { this.customer = customer; }

    public LocalDate getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(LocalDate invoiceDate) { this.invoiceDate = invoiceDate; }

    public Subscription getSubscription() { return subscription; }
    public void setSubscription(Subscription subscription) { this.subscription = subscription; }

    @Override
    public String toString() {
        return "Invoice{" +
                "id=" + id +
                ", amount=" + amount +
                ", invoiceDate=" + invoiceDate +
                ", customer=" + customer +
                ", subscription=" + subscription +
                '}';
    }
}